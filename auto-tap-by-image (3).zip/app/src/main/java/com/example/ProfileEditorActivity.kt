package com.example

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import coil.compose.rememberAsyncImagePainter
import com.example.data.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SlateCardBg
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldReady
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextLight

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

class ProfileEditorActivity : ComponentActivity() {

    private lateinit var repository: ProfileRepository
    private var profileId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = AppDatabase.getDatabase(this)
        repository = ProfileRepository(db.autoTapDao())

        profileId = intent.getLongExtra(EXTRA_PROFILE_ID, -1L)

        setContent {
            MyApplicationTheme {
                ProfileEditorScreen(
                    profileId = profileId,
                    repository = repository,
                    onBack = { finish() }
                )
            }
        }
    }

    companion object {
        const val EXTRA_PROFILE_ID = "com.example.extra.PROFILE_ID"
    }
}

enum class EditorSubScreen {
    MAIN_EDITOR,
    IMAGE_CROPPER,
    TARGET_CONFIG
}

data class AppItem(
    val name: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileEditorScreen(
    profileId: Long,
    repository: ProfileRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Screen navigation
    var currentSubScreen by remember { mutableStateOf(EditorSubScreen.MAIN_EDITOR) }

    // Profile States
    var profileName by remember { mutableStateOf("") }
    var captureInterval by remember { mutableStateOf("500") }
    var targetImages by remember { mutableStateOf<List<TargetImage>>(emptyList()) }
    var packageName by remember { mutableStateOf("") }
    var appName by remember { mutableStateOf("") }
    var loopSequence by remember { mutableStateOf(true) }

    // Cropper & Picker States
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var croppedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    // Cropper Crop Box Slider States (Percentages 0.0 - 1.0)
    var cropLeft by remember { mutableFloatStateOf(0.2f) }
    var cropRight by remember { mutableFloatStateOf(0.8f) }
    var cropTop by remember { mutableFloatStateOf(0.2f) }
    var cropBottom by remember { mutableFloatStateOf(0.8f) }

    // Target Config States
    var targetName by remember { mutableStateOf("") }
    var threshold by remember { mutableFloatStateOf(0.8f) }
    var delayAfterTap by remember { mutableStateOf("1000") }
    var maxTaps by remember { mutableStateOf("0") }
    var priority by remember { mutableStateOf("0") }
    var restrictRegion by remember { mutableStateOf(false) }
    var regX by remember { mutableStateOf("0") }
    var regY by remember { mutableStateOf("0") }
    var regW by remember { mutableStateOf("300") }
    var regH by remember { mutableStateOf("300") }
    var timeoutSecsText by remember { mutableStateOf("10") }
    var actionType by remember { mutableStateOf("TAP") }
    var holdDurationMsText by remember { mutableStateOf("2000") }

    // Load Profile and Targets
    LaunchedEffect(profileId) {
        if (profileId != -1L) {
            repository.getProfileWithTargets(profileId).collect { relation ->
                relation?.let {
                    profileName = it.profile.name
                    captureInterval = it.profile.captureIntervalMs.toString()
                    targetImages = it.targets
                    packageName = it.profile.packageName
                    appName = it.profile.appName
                    loopSequence = it.profile.loopSequence
                }
            }
        } else {
            profileName = "Profil Baru"
            packageName = ""
            appName = ""
            loopSequence = true
        }
    }

    // Photo Picker Contract
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedImageUri = uri
            coroutineScope.launch(Dispatchers.IO) {
                val bitmap = loadBitmapFromUri(context, uri)
                if (bitmap != null) {
                    originalBitmap = bitmap
                    // Reset crop sliders
                    cropLeft = 0.2f
                    cropRight = 0.8f
                    cropTop = 0.2f
                    cropBottom = 0.8f
                    currentSubScreen = EditorSubScreen.IMAGE_CROPPER
                } else {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Gagal memuat gambar", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (currentSubScreen) {
                            EditorSubScreen.MAIN_EDITOR -> "Edit Profil Auto Tap"
                            EditorSubScreen.IMAGE_CROPPER -> "Crop Gambar Target"
                            EditorSubScreen.TARGET_CONFIG -> "Konfigurasi Gambar Target"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        letterSpacing = (-0.5).sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        when (currentSubScreen) {
                            EditorSubScreen.MAIN_EDITOR -> onBack()
                            EditorSubScreen.IMAGE_CROPPER -> currentSubScreen = EditorSubScreen.MAIN_EDITOR
                            EditorSubScreen.TARGET_CONFIG -> currentSubScreen = EditorSubScreen.IMAGE_CROPPER
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = CyberCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianBg,
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = ObsidianBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentSubScreen) {
                EditorSubScreen.MAIN_EDITOR -> {
                    val textFieldColors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = BorderSlate,
                        focusedLabelColor = CyberCyan,
                        unfocusedLabelColor = TextMuted,
                        cursorColor = CyberCyan,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = TextLight,
                        focusedContainerColor = SlateCardBg.copy(alpha = 0.3f),
                        unfocusedContainerColor = SlateCardBg.copy(alpha = 0.15f)
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Pengaturan Profil", 
                            fontSize = 18.sp, 
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = (-0.5).sp
                        )

                        OutlinedTextField(
                            value = profileName,
                            onValueChange = { profileName = it },
                            label = { Text("Nama Profil") },
                            colors = textFieldColors,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = captureInterval,
                            onValueChange = { captureInterval = it },
                            label = { Text("Interval Capture (ms)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = textFieldColors,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Target Application Section State & Dialog
                        var showAppPicker by remember { mutableStateOf(false) }
                        val selectedAppIcon = remember(packageName) {
                            if (packageName.isNotEmpty()) {
                                try {
                                    context.packageManager.getApplicationIcon(packageName)
                                } catch (e: Exception) {
                                    null
                                }
                            } else {
                                null
                            }
                        }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, BorderSlate, RoundedCornerShape(16.dp)),
                            colors = CardDefaults.cardColors(containerColor = SlateCardBg.copy(alpha = 0.4f))
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Aplikasi Target (Auto-Launch)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                    if (packageName.isNotEmpty()) {
                                        TextButton(
                                            onClick = {
                                                packageName = ""
                                                appName = ""
                                            },
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("Hapus", color = Color(0xFFEF4444), fontSize = 12.sp)
                                        }
                                    }
                                }

                                if (packageName.isEmpty()) {
                                    Button(
                                        onClick = { showAppPicker = true },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = CyberCyan,
                                            contentColor = ObsidianBg
                                        ),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.Android, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("PILIH APLIKASI", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color.Black.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                                            .border(1.dp, BorderSlate.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                            .clickable { showAppPicker = true }
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (selectedAppIcon != null) {
                                            Image(
                                                painter = rememberAsyncImagePainter(selectedAppIcon),
                                                contentDescription = appName,
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                            )
                                        } else {
                                            Box(
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                                    .border(1.dp, BorderSlate, RoundedCornerShape(8.dp)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.Android, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(24.dp))
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = appName,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = Color.White
                                            )
                                            Text(
                                                text = packageName,
                                                fontSize = 11.sp,
                                                color = TextMuted
                                            )
                                        }

                                        Icon(
                                            Icons.Default.Edit,
                                            contentDescription = "Edit",
                                            tint = CyberCyan,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Loop Sequence Toggle Card
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, BorderSlate, RoundedCornerShape(16.dp)),
                            colors = CardDefaults.cardColors(containerColor = SlateCardBg)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Loop Sequence",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (loopSequence) "Ulangi dari Langkah 1 terus-menerus" else "Berhenti setelah langkah terakhir selesai",
                                        fontSize = 11.sp,
                                        color = TextMuted
                                    )
                                }
                                Switch(
                                    checked = loopSequence,
                                    onCheckedChange = { loopSequence = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = CyberCyan,
                                        checkedTrackColor = CyberCyan.copy(alpha = 0.3f)
                                    )
                                )
                            }
                        }

                        if (showAppPicker) {
                            var searchQuery by remember { mutableStateOf("") }
                            val appsList = remember {
                                val pm = context.packageManager
                                val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                                    addCategory(Intent.CATEGORY_LAUNCHER)
                                }
                                val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
                                resolveInfos.map { resolveInfo ->
                                    AppItem(
                                        name = resolveInfo.loadLabel(pm).toString(),
                                        packageName = resolveInfo.activityInfo.packageName,
                                        icon = resolveInfo.loadIcon(pm)
                                    )
                                }.distinctBy { it.packageName }.sortedBy { it.name }
                            }
                            
                            val filteredApps = appsList.filter { 
                                it.name.contains(searchQuery, ignoreCase = true) || 
                                it.packageName.contains(searchQuery, ignoreCase = true) 
                            }

                            AlertDialog(
                                onDismissRequest = { showAppPicker = false },
                                title = {
                                    Column {
                                        Text(
                                            text = "Pilih Aplikasi Target",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        OutlinedTextField(
                                            value = searchQuery,
                                            onValueChange = { searchQuery = it },
                                            placeholder = { Text("Cari aplikasi...", color = TextMuted) },
                                            singleLine = true,
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = CyberCyan,
                                                unfocusedBorderColor = BorderSlate,
                                                focusedTextColor = Color.White,
                                                unfocusedTextColor = TextLight,
                                                focusedContainerColor = SlateCardBg.copy(alpha = 0.3f),
                                                unfocusedContainerColor = SlateCardBg.copy(alpha = 0.15f)
                                            ),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.fillMaxWidth(),
                                            leadingIcon = {
                                                Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted)
                                            }
                                        )
                                    }
                                },
                                text = {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(300.dp)
                                    ) {
                                        if (filteredApps.isEmpty()) {
                                            Box(
                                                modifier = Modifier.fillMaxSize(),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("Aplikasi tidak ditemukan", color = TextMuted)
                                            }
                                        } else {
                                            LazyColumn(
                                                modifier = Modifier.fillMaxSize(),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                items(filteredApps) { app ->
                                                    Card(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .clickable {
                                                                packageName = app.packageName
                                                                appName = app.name
                                                                showAppPicker = false
                                                            },
                                                        colors = CardDefaults.cardColors(containerColor = SlateCardBg.copy(alpha = 0.6f)),
                                                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSlate.copy(alpha = 0.5f)),
                                                        shape = RoundedCornerShape(12.dp)
                                                    ) {
                                                        Row(
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .padding(10.dp),
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Image(
                                                                painter = rememberAsyncImagePainter(app.icon),
                                                                contentDescription = app.name,
                                                                modifier = Modifier
                                                                    .size(40.dp)
                                                                    .clip(RoundedCornerShape(8.dp))
                                                            )
                                                            Spacer(modifier = Modifier.width(12.dp))
                                                            Column {
                                                                Text(
                                                                    text = app.name,
                                                                    fontWeight = FontWeight.SemiBold,
                                                                    color = Color.White,
                                                                    fontSize = 14.sp
                                                                )
                                                                Text(
                                                                    text = app.packageName,
                                                                    color = TextMuted,
                                                                    fontSize = 11.sp
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                },
                                confirmButton = {
                                    TextButton(onClick = { showAppPicker = false }) {
                                        Text("Batal", color = CyberCyan)
                                    }
                                },
                                containerColor = ObsidianBg,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.border(1.dp, BorderSlate, RoundedCornerShape(16.dp))
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Gambar Target Visual", 
                                fontSize = 16.sp, 
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Button(
                                onClick = { imagePickerLauncher.launch("image/*") },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberCyan,
                                    contentColor = ObsidianBg
                                ),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Tambah Target", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (targetImages.isEmpty()) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, BorderSlate, RoundedCornerShape(16.dp))
                                    .padding(vertical = 8.dp),
                                colors = CardDefaults.cardColors(containerColor = SlateCardBg.copy(alpha = 0.5f))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Image, 
                                        contentDescription = null, 
                                        modifier = Modifier.size(48.dp),
                                        tint = TextMuted
                                    )
                                    Text("Belum ada gambar target", fontWeight = FontWeight.Bold, color = Color.White)
                                    Text(
                                        "Unggah screenshot tombol atau ikon yang ingin di-tap otomatis secara real-time.",
                                        fontSize = 11.sp,
                                        color = TextMuted,
                                        modifier = Modifier.align(Alignment.CenterHorizontally)
                                    )
                                }
                            }
                        } else {
                            val sortedTargets = targetImages.sortedBy { it.priority }
                            sortedTargets.forEachIndexed { index, target ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, BorderSlate, RoundedCornerShape(16.dp)),
                                    colors = CardDefaults.cardColors(containerColor = SlateCardBg)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Image Preview
                                        Box(
                                            modifier = Modifier
                                                .size(64.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(Color.Black.copy(alpha = 0.2f))
                                                .border(1.dp, BorderSlate, RoundedCornerShape(8.dp))
                                        ) {
                                            Image(
                                                painter = rememberAsyncImagePainter(File(target.filePath)),
                                                contentDescription = target.name,
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Fit
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        // Meta Details
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Langkah ${index + 1}: ${target.name}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                                            val actionLabel = when (target.actionType) {
                                                "LONG_PRESS" -> "Tekan Tahan (${target.holdDurationMs}ms)"
                                                "WAIT_ONLY" -> "Tunggu Saja"
                                                "WAIT_DISAPPEAR" -> "Tunggu Hilang"
                                                else -> "Ketuk"
                                            }
                                            Text("Tindakan: $actionLabel", fontSize = 12.sp, color = CyberCyan, fontWeight = FontWeight.SemiBold)
                                            Text("Akurasi: ${target.threshold} | Delay: ${target.delayAfterTapMs}ms\nTimeout: ${target.timeoutSeconds}s", fontSize = 11.sp, color = TextMuted)
                                            if (target.maxTaps > 0) {
                                                Text("Tap Maks: ${target.tapCount}/${target.maxTaps}", fontSize = 11.sp, color = CyberCyan, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        // Reorder Actions
                                        if (index > 0) {
                                            IconButton(onClick = {
                                                coroutineScope.launch {
                                                    val prevTarget = sortedTargets[index - 1]
                                                    val currentPriority = target.priority
                                                    val prevPriority = prevTarget.priority
                                                    val newCurrentPriority = if (currentPriority == prevPriority) prevPriority - 1 else prevPriority
                                                    repository.updateTargetImage(target.copy(priority = newCurrentPriority))
                                                    repository.updateTargetImage(prevTarget.copy(priority = currentPriority))
                                                }
                                            }) {
                                                Icon(Icons.Default.ArrowUpward, contentDescription = "Pindah Ke Atas", tint = CyberCyan)
                                            }
                                        }

                                        if (index < sortedTargets.size - 1) {
                                            IconButton(onClick = {
                                                coroutineScope.launch {
                                                    val nextTarget = sortedTargets[index + 1]
                                                    val currentPriority = target.priority
                                                    val nextPriority = nextTarget.priority
                                                    val newCurrentPriority = if (currentPriority == nextPriority) nextPriority + 1 else nextPriority
                                                    repository.updateTargetImage(target.copy(priority = newCurrentPriority))
                                                    repository.updateTargetImage(nextTarget.copy(priority = currentPriority))
                                                }
                                            }) {
                                                Icon(Icons.Default.ArrowDownward, contentDescription = "Pindah Ke Bawah", tint = CyberCyan)
                                            }
                                        }

                                        // Actions
                                        IconButton(onClick = {
                                            coroutineScope.launch {
                                                repository.deleteTargetImage(target)
                                                // Delete physical file
                                                File(target.filePath).delete()
                                                Toast.makeText(context, "Target dihapus", Toast.LENGTH_SHORT).show()
                                            }
                                        }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = Color(0xFFEF4444))
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // Save Button
                        Button(
                            onClick = {
                                val interval = captureInterval.toLongOrNull() ?: 500L
                                if (profileName.isBlank()) {
                                    Toast.makeText(context, "Nama profil tidak boleh kosong", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                coroutineScope.launch {
                                    if (profileId == -1L) {
                                        repository.insertProfile(Profile(name = profileName, captureIntervalMs = interval, packageName = packageName, appName = appName, loopSequence = loopSequence))
                                    } else {
                                        repository.updateProfile(Profile(id = profileId, name = profileName, captureIntervalMs = interval, packageName = packageName, appName = appName, loopSequence = loopSequence))
                                    }
                                    onBack()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldReady,
                                contentColor = ObsidianBg
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            Text("SIMPAN PENGATURAN PROFIL", fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 0.5.sp)
                        }
                    }
                }

                EditorSubScreen.IMAGE_CROPPER -> {
                    originalBitmap?.let { bitmap ->
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = "Geser slider untuk menentukan area pemotongan target", 
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                fontSize = 14.sp
                            )

                            // Main Image Bounding Box Visualization
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color.Black.copy(alpha = 0.4f))
                                    .border(1.dp, BorderSlate, RoundedCornerShape(16.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Fit
                                )

                                // Tech-themed holographic border targeting the cropped area
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .border(2.dp, CyberCyan.copy(alpha = 0.7f))
                                )
                            }

                            // Sliders for Cropping Box (Simulating dynamic cropper)
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, BorderSlate, RoundedCornerShape(16.dp)),
                                colors = CardDefaults.cardColors(containerColor = SlateCardBg)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "Koordinat Potong (Kiri - Kanan):", 
                                        fontSize = 12.sp, 
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Kiri: ", fontSize = 11.sp, color = TextMuted, modifier = Modifier.width(44.dp))
                                        Slider(
                                            value = cropLeft,
                                            onValueChange = { cropLeft = it.coerceAtMost(cropRight - 0.1f) },
                                            colors = SliderDefaults.colors(activeTrackColor = CyberCyan, thumbColor = CyberCyan),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Kanan: ", fontSize = 11.sp, color = TextMuted, modifier = Modifier.width(44.dp))
                                        Slider(
                                            value = cropRight,
                                            onValueChange = { cropRight = it.coerceAtLeast(cropLeft + 0.1f) },
                                            colors = SliderDefaults.colors(activeTrackColor = CyberCyan, thumbColor = CyberCyan),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = "Koordinat Potong (Atas - Bawah):", 
                                        fontSize = 12.sp, 
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Atas: ", fontSize = 11.sp, color = TextMuted, modifier = Modifier.width(44.dp))
                                        Slider(
                                            value = cropTop,
                                            onValueChange = { cropTop = it.coerceAtMost(cropBottom - 0.1f) },
                                            colors = SliderDefaults.colors(activeTrackColor = CyberCyan, thumbColor = CyberCyan),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Bawah: ", fontSize = 11.sp, color = TextMuted, modifier = Modifier.width(44.dp))
                                        Slider(
                                            value = cropBottom,
                                            onValueChange = { cropBottom = it.coerceAtLeast(cropTop + 0.1f) },
                                            colors = SliderDefaults.colors(activeTrackColor = CyberCyan, thumbColor = CyberCyan),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }

                            // Crop Confirm Button
                            Button(
                                onClick = {
                                    coroutineScope.launch(Dispatchers.Default) {
                                        val cropped = cropBitmap(bitmap, cropLeft, cropRight, cropTop, cropBottom)
                                        if (cropped != null) {
                                            croppedBitmap = cropped
                                            // Reset target config variables
                                            targetName = "Target_${System.currentTimeMillis() % 10000}"
                                            threshold = 0.8f
                                            delayAfterTap = "1000"
                                            maxTaps = "0"
                                            priority = targetImages.size.toString()
                                            restrictRegion = false
                                            timeoutSecsText = "10"
                                            actionType = "TAP"
                                            holdDurationMsText = "2000"

                                            withContext(Dispatchers.Main) {
                                                currentSubScreen = EditorSubScreen.TARGET_CONFIG
                                            }
                                        } else {
                                            withContext(Dispatchers.Main) {
                                                Toast.makeText(context, "Potong gagal. Periksa koordinat.", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberCyan,
                                    contentColor = ObsidianBg
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                            ) {
                                Icon(Icons.Default.Crop, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("LAKUKAN PEMOTONGAN", fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 0.5.sp)
                            }
                        }
                    }
                }

                EditorSubScreen.TARGET_CONFIG -> {
                    croppedBitmap?.let { cropped ->
                        val textFieldColors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = BorderSlate,
                            focusedLabelColor = CyberCyan,
                            unfocusedLabelColor = TextMuted,
                            cursorColor = CyberCyan,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = TextLight,
                            focusedContainerColor = SlateCardBg.copy(alpha = 0.3f),
                            unfocusedContainerColor = SlateCardBg.copy(alpha = 0.15f)
                        )

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = "Review Hasil Pemotongan & Konfigurasi", 
                                fontWeight = FontWeight.Bold, 
                                fontSize = 16.sp,
                                color = Color.White,
                                letterSpacing = (-0.5).sp
                            )

                            // Preview Cropped Thumbnail
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Black.copy(alpha = 0.2f))
                                    .border(1.dp, BorderSlate, RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    bitmap = cropped.asImageBitmap(),
                                    contentDescription = "Preview Crop",
                                    modifier = Modifier.wrapContentSize(),
                                    contentScale = ContentScale.Fit
                                )
                            }

                            // Configuration Form fields
                            OutlinedTextField(
                                value = targetName,
                                onValueChange = { targetName = it },
                                label = { Text("Nama Target (cth: Tombol Mulai)") },
                                colors = textFieldColors,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Tipe Tindakan Otomatis Card
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, BorderSlate, RoundedCornerShape(16.dp)),
                                colors = CardDefaults.cardColors(containerColor = SlateCardBg)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = "Tipe Tindakan Otomatis",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                    
                                    val actionTypes = listOf(
                                        Triple("TAP", "Ketuk (Click)", "Simulasi sentuhan biasa sekali ketuk di tengah gambar."),
                                        Triple("LONG_PRESS", "Tekan & Tahan", "Berguna untuk menurunkan pasukan game (hold)."),
                                        Triple("WAIT_ONLY", "Tunggu Saja", "Hanya menunggu gambar muncul lalu lanjut tanpa menyentuh."),
                                        Triple("WAIT_DISAPPEAR", "Tunggu Gambar Hilang", "Menunggu layar berubah sampai gambar ini tidak ada lagi.")
                                    )
                                    
                                    actionTypes.forEach { (type, title, desc) ->
                                        val isSelected = actionType == type
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(if (isSelected) CyberCyan.copy(alpha = 0.12f) else Color.Transparent)
                                                .border(
                                                    width = 1.dp,
                                                    color = if (isSelected) CyberCyan else BorderSlate.copy(alpha = 0.4f),
                                                    shape = RoundedCornerShape(10.dp)
                                                )
                                                .clickable { actionType = type }
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            RadioButton(
                                                selected = isSelected,
                                                onClick = { actionType = type },
                                                colors = RadioButtonDefaults.colors(selectedColor = CyberCyan, unselectedColor = TextMuted)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(text = title, fontWeight = FontWeight.Bold, color = if (isSelected) CyberCyan else Color.White, fontSize = 13.sp)
                                                Text(text = desc, color = TextMuted, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            if (actionType == "LONG_PRESS") {
                                OutlinedTextField(
                                    value = holdDurationMsText,
                                    onValueChange = { holdDurationMsText = it },
                                    label = { Text("Durasi Tekan Tahan (ms)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    colors = textFieldColors,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            // Threshold Slider
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, BorderSlate, RoundedCornerShape(16.dp)),
                                colors = CardDefaults.cardColors(containerColor = SlateCardBg)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "Threshold Confidence (Akurasi): ${String.format("%.2f", threshold)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color.White
                                    )
                                    Slider(
                                        value = threshold,
                                        onValueChange = { threshold = it },
                                        valueRange = 0.5f..1.0f,
                                        colors = SliderDefaults.colors(activeTrackColor = CyberCyan, thumbColor = CyberCyan)
                                    )
                                    Text(
                                        "Makin besar angkanya, makin ketat deteksi visual gambarnya.", 
                                        fontSize = 11.sp, 
                                        color = TextMuted
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = delayAfterTap,
                                onValueChange = { delayAfterTap = it },
                                label = { Text("Delay Setelah Click (ms)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = textFieldColors,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = maxTaps,
                                onValueChange = { maxTaps = it },
                                label = { Text("Maks Ketukan Sesi (0 = Tanpa Batas)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = textFieldColors,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = priority,
                                onValueChange = { priority = it },
                                label = { Text("Urutan Step Sequence (0 = Step Pertama, 1 = Step Kedua, dst)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = textFieldColors,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = timeoutSecsText,
                                onValueChange = { timeoutSecsText = it },
                                label = { Text("Timeout Gambar Tidak Ditemukan (Detik)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = textFieldColors,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Restrict Region toggle
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Batasi Area Pencarian", fontWeight = FontWeight.Bold, color = Color.White)
                                    Text("Mencari di area koordinat tertentu (lebih hemat baterai & cepat)", fontSize = 11.sp, color = TextMuted)
                                }
                                Switch(
                                    checked = restrictRegion,
                                    onCheckedChange = { restrictRegion = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = CyberCyan,
                                        checkedTrackColor = CyberCyan.copy(alpha = 0.3f)
                                    )
                                )
                            }

                            if (restrictRegion) {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, BorderSlate, RoundedCornerShape(16.dp)),
                                    colors = CardDefaults.cardColors(containerColor = SlateCardBg)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text("Koordinat Region Layar (px)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedTextField(
                                                value = regX,
                                                onValueChange = { regX = it },
                                                label = { Text("X") },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                colors = textFieldColors,
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1f)
                                            )
                                            OutlinedTextField(
                                                value = regY,
                                                onValueChange = { regY = it },
                                                label = { Text("Y") },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                colors = textFieldColors,
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedTextField(
                                                value = regW,
                                                onValueChange = { regW = it },
                                                label = { Text("Lebar") },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                colors = textFieldColors,
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1f)
                                            )
                                            OutlinedTextField(
                                                value = regH,
                                                onValueChange = { regH = it },
                                                label = { Text("Tinggi") },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                colors = textFieldColors,
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Save Target Button
                            Button(
                                onClick = {
                                    if (targetName.isBlank()) {
                                        Toast.makeText(context, "Nama target harus diisi", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    coroutineScope.launch(Dispatchers.IO) {
                                        // Save bitmap as PNG file
                                        val filename = "target_${UUID.randomUUID()}.png"
                                        val targetFile = File(context.filesDir, filename)
                                        val out = FileOutputStream(targetFile)
                                        cropped.compress(Bitmap.CompressFormat.PNG, 100, out)
                                        out.flush()
                                        out.close()

                                        // Ensure profile exists first
                                        var pId = profileId
                                        if (pId == -1L) {
                                            val interval = captureInterval.toLongOrNull() ?: 500L
                                            pId = repository.insertProfile(
                                                Profile(name = profileName, captureIntervalMs = interval, packageName = packageName, appName = appName, loopSequence = loopSequence)
                                            )
                                        }

                                        // Insert TargetImage in Database
                                        val targetImage = TargetImage(
                                            profileId = pId,
                                            name = targetName,
                                            filePath = targetFile.absolutePath,
                                            threshold = threshold,
                                            delayAfterTapMs = delayAfterTap.toLongOrNull() ?: 1000L,
                                            maxTaps = maxTaps.toIntOrNull() ?: 0,
                                            priority = priority.toIntOrNull() ?: 0,
                                            restrictRegion = restrictRegion,
                                            regionX = regX.toIntOrNull() ?: 0,
                                            regionY = regY.toIntOrNull() ?: 0,
                                            regionWidth = regW.toIntOrNull() ?: 300,
                                            regionHeight = regH.toIntOrNull() ?: 300,
                                            timeoutSeconds = timeoutSecsText.toIntOrNull() ?: 10,
                                            actionType = actionType,
                                            holdDurationMs = holdDurationMsText.toLongOrNull() ?: 1000L
                                        )

                                        repository.insertTargetImage(targetImage)

                                        withContext(Dispatchers.Main) {
                                            Toast.makeText(context, "Target disimpan!", Toast.LENGTH_SHORT).show()
                                            // Back to profile editor
                                            currentSubScreen = EditorSubScreen.MAIN_EDITOR
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldReady,
                                    contentColor = ObsidianBg
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("SIMPAN GAMBAR TARGET", fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 0.5.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// Utility Functions for Image Slicing
private fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap? {
    return try {
        val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
        BitmapFactory.decodeStream(inputStream)
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}

private fun cropBitmap(
    bitmap: Bitmap,
    leftPct: Float,
    rightPct: Float,
    topPct: Float,
    bottomPct: Float
): Bitmap? {
    return try {
        val x = (leftPct * bitmap.width).toInt()
        val y = (topPct * bitmap.height).toInt()
        val width = ((rightPct - leftPct) * bitmap.width).toInt()
        val height = ((bottomPct - topPct) * bitmap.height).toInt()

        // Validate bounds
        val startX = x.coerceIn(0, bitmap.width - 1)
        val startY = y.coerceIn(0, bitmap.height - 1)
        val rectWidth = width.coerceIn(1, bitmap.width - startX)
        val rectHeight = height.coerceIn(1, bitmap.height - startY)

        Bitmap.createBitmap(bitmap, startX, startY, rectWidth, rectHeight)
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}
