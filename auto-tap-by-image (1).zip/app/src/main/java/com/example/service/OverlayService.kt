package com.example.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.MainActivity
import com.example.service.ScreenCaptureService.Companion.ACTION_PAUSE_TAPPING
import com.example.service.ScreenCaptureService.Companion.ACTION_RESUME_TAPPING
import com.example.service.ScreenCaptureService.Companion.ACTION_STOP
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class OverlayService : Service() {

    private val job = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + job)

    private var windowManager: WindowManager? = null
    private var overlayView: FrameLayout? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private var isExpanded = false

    // programmatically created subviews
    private var collapsedLayout: LinearLayout? = null
    private var expandedLayout: LinearLayout? = null
    private var playPauseButton: ImageView? = null
    private var statusText: TextView? = null
    private var profileNameText: TextView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createFloatingWidget()
        observeServiceState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val profileName = intent?.getStringExtra(EXTRA_PROFILE_NAME) ?: "No Profile"
        profileNameText?.text = profileName
        return START_NOT_STICKY
    }

    private fun createFloatingWidget() {
        val context = this
        overlayView = FrameLayout(context)

        // Setup layout params for System Overlay
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 200
        }

        // --- DRAWABLES (Rounded corners programmatically) ---
        val collapsedBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#121212")) // Dark Onyx
            setStroke(dpToPx(2), Color.parseColor("#424242")) // Accent ring
        }

        val expandedBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpToPx(16).toFloat()
            setColor(Color.parseColor("#1e1e1e")) // Dark Slate
            setStroke(dpToPx(2), Color.parseColor("#6200EE")) // Neon purple border
        }

        // ================= COLLAPSED LAYOUT =================
        collapsedLayout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = collapsedBg
            setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(8))
            
            // Icon (Target crosshair)
            val icon = ImageView(context).apply {
                setImageResource(android.R.drawable.ic_menu_compass)
                setColorFilter(Color.parseColor("#FFD700")) // Gold
                layoutParams = LinearLayout.LayoutParams(dpToPx(40), dpToPx(40))
            }
            addView(icon)
        }

        // ================= EXPANDED CONTROLLER LAYOUT =================
        expandedLayout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = expandedBg
            visibility = View.GONE
            setPadding(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8))

            // Text Info Panel
            val infoLayout = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    rightMargin = dpToPx(12)
                }
            }

            profileNameText = TextView(context).apply {
                text = "Auto Tap"
                setTextColor(Color.WHITE)
                textSize = 13f
                paint.isFakeBoldText = true
            }
            infoLayout.addView(profileNameText)

            statusText = TextView(context).apply {
                text = "Idle"
                setTextColor(Color.parseColor("#AAAAAA"))
                textSize = 10f
            }
            infoLayout.addView(statusText)
            addView(infoLayout)

            // Button 1: Play/Pause
            playPauseButton = ImageView(context).apply {
                setImageResource(android.R.drawable.ic_media_play)
                setColorFilter(Color.parseColor("#00E676")) // Neon green
                setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(8))
                layoutParams = LinearLayout.LayoutParams(dpToPx(40), dpToPx(40)).apply {
                    rightMargin = dpToPx(8)
                }
                isClickable = true
                
                val bg = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#292929"))
                }
                background = bg

                setOnClickListener {
                    toggleTappingState()
                }
            }
            addView(playPauseButton)

            // Button 2: Stop/Close Overlay
            val stopButton = ImageView(context).apply {
                setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
                setColorFilter(Color.parseColor("#FF1744")) // Vibrant Red
                setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(8))
                layoutParams = LinearLayout.LayoutParams(dpToPx(40), dpToPx(40))
                isClickable = true
                
                val bg = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#292929"))
                }
                background = bg

                setOnClickListener {
                    stopAllServices()
                }
            }
            addView(stopButton)
        }

        // Add sublayouts to frame container
        overlayView?.addView(collapsedLayout)
        overlayView?.addView(expandedLayout)

        // Set touch/drag listeners
        setupDragListener()

        // Inflate view into WindowManager
        windowManager?.addView(overlayView, layoutParams)
    }

    private fun toggleTappingState() {
        val currentState = ScreenCaptureService.state.value
        val intent = Intent(this, ScreenCaptureService::class.java)
        
        if (currentState == ScreenCaptureService.ServiceState.RUNNING) {
            intent.action = ACTION_PAUSE_TAPPING
        } else {
            intent.action = ACTION_RESUME_TAPPING
        }
        startService(intent)
    }

    private fun stopAllServices() {
        // Stop screen capturing
        val stopCaptureIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ACTION_STOP
        }
        startService(stopCaptureIntent)

        // Stop this overlay service
        stopSelf()
    }

    private fun observeServiceState() {
        serviceScope.launch {
            ScreenCaptureService.state.collect { state ->
                when (state) {
                    ScreenCaptureService.ServiceState.STOPPED -> {
                        statusText?.text = "Stopped"
                        playPauseButton?.setImageResource(android.R.drawable.ic_media_play)
                        playPauseButton?.setColorFilter(Color.parseColor("#00E676"))
                    }
                    ScreenCaptureService.ServiceState.IDLE -> {
                        statusText?.text = "Ready"
                        playPauseButton?.setImageResource(android.R.drawable.ic_media_play)
                        playPauseButton?.setColorFilter(Color.parseColor("#00E676"))
                    }
                    ScreenCaptureService.ServiceState.RUNNING -> {
                        statusText?.text = "Scanning..."
                        playPauseButton?.setImageResource(android.R.drawable.ic_media_pause)
                        playPauseButton?.setColorFilter(Color.parseColor("#FFD700")) // Gold/Yellow pause
                    }
                    ScreenCaptureService.ServiceState.PAUSED -> {
                        statusText?.text = "Paused"
                        playPauseButton?.setImageResource(android.R.drawable.ic_media_play)
                        playPauseButton?.setColorFilter(Color.parseColor("#00E676"))
                    }
                }
            }
        }
    }

    private fun setupDragListener() {
        overlayView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isDragging = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val lp = layoutParams ?: return false
                val wm = windowManager ?: return false

                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = lp.x
                        initialY = lp.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isDragging = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()

                        // Treat as drag if moved more than 8 pixels
                        if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
                            isDragging = true
                        }

                        if (isDragging) {
                            lp.x = initialX + dx
                            lp.y = initialY + dy
                            wm.updateViewLayout(overlayView, lp)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!isDragging) {
                            // Toggles Expanded / Collapsed state upon click
                            isExpanded = !isExpanded
                            if (isExpanded) {
                                collapsedLayout?.visibility = View.GONE
                                expandedLayout?.visibility = View.VISIBLE
                            } else {
                                collapsedLayout?.visibility = View.VISIBLE
                                expandedLayout?.visibility = View.GONE
                            }
                        }
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun dpToPx(dp: Int): Int {
        val density = resources.displayMetrics.density
        return Math.round(dp * density)
    }

    override fun onDestroy() {
        serviceScope.cancel()
        overlayView?.let {
            windowManager?.removeView(it)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "OverlayService"
        const val EXTRA_PROFILE_NAME = "com.example.extra.PROFILE_NAME"
    }
}
